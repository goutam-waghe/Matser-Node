export const userType = {
    admin: 1,
    user: 2
};

export const languageSupport = {
    hindi: "hi",
    english: "en"
};
